import 'package:doctor/page/alarm.dart';
import 'package:marquee/marquee.dart';
import 'package:doctor/page/history.dart';
import 'package:doctor/page/profile.dart';
import 'package:doctor/page/video.dart';
import 'package:doctor/screen/login.dart';
import 'package:flutter/material.dart';

import '../findquestion/findquestion.dart';
import 'package:blinking_text/blinking_text.dart';
import 'package:shared_preferences/shared_preferences.dart';
class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {


  @override
  void initState() {
    super.initState();
    setname();
  }
String? name;

    setname()async{
      SharedPreferences prefs =await SharedPreferences.getInstance();
      setState((){
        name=prefs.getString('user');
      });


    }

  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          backgroundColor: Colors.white,
          automaticallyImplyLeading: false,
          elevation: 0,
          centerTitle: true,
          title:  Text(
            'Hello, $name',
            style: TextStyle(
                color: Colors.black, fontSize: 20, fontWeight: FontWeight.w500),
          ),
          iconTheme: const IconThemeData(color: Colors.black),
          actions: const [
            Icon(
              Icons.notifications,
              color: Colors.black,
              size: 30,
            )
          ]),
      body: name==null ? Center(child: CircularProgressIndicator()): SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Container(
                  padding: const EdgeInsets.only(top: 40, left: 50),
                  height: 100,
                  width: 400,
                  decoration: BoxDecoration(
                      color: const Color(0xFF0D47A1),
                      borderRadius: BorderRadius.circular(20)),
                  child: const BlinkText(
                      'Emergency Set Alarm',
                      style: TextStyle(fontSize:25.0, color: Colors.white),
                      beginColor: Colors.red,
                      endColor: Colors.green,
                      times: 10,
                      duration: Duration(seconds: 1)
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(10),
                child: GridView.count(
                  crossAxisCount: 2,
                  primary: false,
                  shrinkWrap: true,
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.push(context,
                            MaterialPageRoute(builder: (_) => const AlarmPage()));
                      },
                      child: Container(
                        child: Card(
                            color: Colors.indigo[100],
                            shape: const RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(20))),
                            elevation: 10,
                            child: ClipRRect(
                              borderRadius:
                                  const BorderRadius.all(Radius.circular(10)),
                              child: Stack(
                                children: [
                                  Container(
                                      padding: const EdgeInsets.only(left: 30),
                                      child: const Icon(
                                        Icons.alarm,
                                        size: 100,
                                        color: Color(0xFF0D47A1),
                                      )),
                                  Container(
                                    margin: const EdgeInsets.only(
                                        top: 100, left: 30),
                                    child: const Text(
                                      'Set Alarm For\n    Medicine',
                                      style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  )
                                ],
                              ),
                            )),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.push(context,
                            MaterialPageRoute(builder: (_) => const Video()));
                      },
                      child: Container(
                        child: Card(
                            color: Colors.indigo[100],
                            shape: const RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(20))),
                            elevation: 10,
                            child: ClipRRect(
                              borderRadius:
                                  const BorderRadius.all(Radius.circular(10)),
                              child: Stack(
                                children: [
                                  Container(
                                      padding: const EdgeInsets.only(
                                          left: 20, top: 20),
                                      child: const Icon(
                                        Icons.video_collection,
                                        size: 100,
                                        color: Color(0xFF0D47A1),
                                      )),
                                  Container(
                                    margin: const EdgeInsets.only(
                                        top: 120, left: 40),
                                    child: const Text(
                                      'View Video',
                                      style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  )
                                ],
                              ),
                            )),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                         Navigator.push(context,
                             MaterialPageRoute(builder: (_) => const Find()));
                      },
                      child: Container(
                        child: Card(
                            color: Colors.indigo[100],
                            shape: const RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(20))),
                            elevation: 10,
                            child: ClipRRect(
                              borderRadius:
                                  const BorderRadius.all(Radius.circular(10)),
                              child: Stack(
                                children: [
                                  Container(
                                      padding:
                                          const EdgeInsets.only(left: 20, top: 20),
                                      child: const Icon(
                                        Icons.question_mark_rounded,
                                        size: 100,
                                        color: Color(0xFF0D47A1),
                                      )),
                                  Container(
                                    margin:
                                        const EdgeInsets.only(top: 120, left: 60),
                                    child: const Text(
                                      'F&Q',
                                      style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  )
                                ],
                              ),
                            )),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.push(context,
                            MaterialPageRoute(builder: (_) => const History()));
                      },
                      child: Container(
                        child: Card(
                            color: Colors.indigo[100],
                            shape: const RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(20))),
                            elevation: 10,
                            child: ClipRRect(
                              borderRadius:
                                  const BorderRadius.all(Radius.circular(10)),
                              child: Stack(
                                children: [
                                  Container(
                                      padding:
                                          const EdgeInsets.only(left: 20, top: 20),
                                      child: const Icon(
                                        Icons.history,
                                        size: 100,
                                        color: Color(0xFF0D47A1),
                                      )),
                                  Container(
                                    margin:
                                        const EdgeInsets.only(top: 120, left: 20),
                                    child: const Text(
                                      'Epilepsy History',
                                      style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  )
                                ],
                              ),
                            )),
                      ),
                    ),
                    InkWell(
                      onTap: (){
                        Navigator.push(context,
                            MaterialPageRoute(builder: (_) => const Profile()));
                      },
                      child: Container(
                        child: Card(
                            color: Colors.indigo[100],
                            shape: const RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(20))),
                            elevation: 10,
                            child: ClipRRect(
                              borderRadius:
                                  const BorderRadius.all(Radius.circular(10)),
                              child: Stack(
                                children: [
                                  Container(
                                      padding:
                                          const EdgeInsets.only(left: 20, top: 20),
                                      child: const Icon(
                                        Icons.person_pin,
                                        size: 100,
                                        color: Color(0xFF0D47A1),
                                      )),
                                  Container(
                                    margin:
                                        const EdgeInsets.only(top: 120, left: 50),
                                    child: const Text(
                                      'Profile',
                                      style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  )
                                ],
                              ),
                            )),
                      ),
                    ),
                    InkWell(
                      onTap: ()async{
                        SharedPreferences prefs =await SharedPreferences.getInstance();
                        prefs.clear();
                        Navigator.push(context,
                            MaterialPageRoute(builder: (_) => const LoginPage()));
                      },
                      child: Container(
                        child: Card(
                            color: Colors.indigo[100],
                            shape: const RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(20))),
                            elevation: 10,
                            child: ClipRRect(
                              borderRadius:
                                  const BorderRadius.all(Radius.circular(10)),
                              child: Stack(
                                children: [
                                  Container(
                                      padding:
                                          const EdgeInsets.only(left: 30, top: 20),
                                      child: const Icon(
                                        Icons.logout,
                                        size: 100,
                                        color: Color(0xFF0D47A1),
                                      )),
                                  Container(
                                    margin:
                                        const EdgeInsets.only(top: 120, left: 50),
                                    child: const Text(
                                      'Log Out',
                                      style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  )
                                ],
                              ),
                            )),
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
