import 'package:flutter/material.dart';

class History extends StatelessWidget {
  const History({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Color(0xFF0D47A1)),
        elevation: 0,
        backgroundColor: Colors.white,
        automaticallyImplyLeading: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Container(
                    padding: const EdgeInsets.only(
                      top: 20,
                    ),
                    height: 100,
                    width: 400,
                    decoration: BoxDecoration(
                        color: Colors.indigo[100],
                        borderRadius: BorderRadius.circular(20)),
                    child:const ListTile(
                      leading:  Icon(
                        Icons.manage_history,
                        color: Colors.red,
                        size: 50,
                      ),
                      title: Text(
                        'First Epilespy',
                        style: TextStyle(
                            color: Color(0xFF0D47A1),
                            fontSize: 16,
                            fontWeight: FontWeight.bold),
                      ),
                      subtitle:  Text(
                        'Wed,2 july 2022 1:00PM',
                        style: TextStyle(
                            color: Color(0xFF0D47A1),
                            fontSize: 14,
                           ),
                      ),
                      trailing: Text(
                        'Message Sent ',
                        style: TextStyle(
                          color: Colors.blue,
                          fontSize: 16,
                        ),
                      ),
                    )),
              ),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Container(
                    padding: const EdgeInsets.only(
                      top: 20,
                    ),
                    height: 100,
                    width: 400,
                    decoration: BoxDecoration(
                        color: Colors.indigo[100],
                        borderRadius: BorderRadius.circular(20)),
                    child:const ListTile(
                      leading:  Icon(
                        Icons.manage_history,
                        color: Colors.red,
                        size: 50,
                      ),
                      title: Text(
                        'First Epilespy',
                        style: TextStyle(
                            color: Color(0xFF0D47A1),
                            fontSize: 16,
                            fontWeight: FontWeight.bold),
                      ),
                      subtitle:  Text(
                        'Wed,2 july 2022 1:00PM',
                        style: TextStyle(
                          color: Color(0xFF0D47A1),
                          fontSize: 14,
                        ),
                      ),
                      trailing: Text(
                        'Message Sent ',
                        style: TextStyle(
                          color: Colors.blue,
                          fontSize: 16,
                        ),
                      ),
                    )),
              ),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Container(
                    padding: const EdgeInsets.only(
                      top: 20,
                    ),
                    height: 100,
                    width: 400,
                    decoration: BoxDecoration(
                        color: Colors.indigo[100],
                        borderRadius: BorderRadius.circular(20)),
                    child:const ListTile(
                      leading:  Icon(
                        Icons.manage_history,
                        color: Colors.red,
                        size: 50,
                      ),
                      title: Text(
                        'First Epilespy',
                        style: TextStyle(
                            color: Color(0xFF0D47A1),
                            fontSize: 16,
                            fontWeight: FontWeight.bold),
                      ),
                      subtitle:  Text(
                        'Wed,2 july 2022 1:00PM',
                        style: TextStyle(
                          color: Color(0xFF0D47A1),
                          fontSize: 14,
                        ),
                      ),
                      trailing: Text(
                        'Message Sent ',
                        style: TextStyle(
                          color: Colors.blue,
                          fontSize: 16,
                        ),
                      ),
                    )),
              ),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Container(
                    padding: const EdgeInsets.only(
                      top: 20,
                    ),
                    height: 100,
                    width: 400,
                    decoration: BoxDecoration(
                        color: Colors.indigo[100],
                        borderRadius: BorderRadius.circular(20)),
                    child:const ListTile(
                      leading:  Icon(
                        Icons.manage_history,
                        color: Colors.red,
                        size: 50,
                      ),
                      title: Text(
                        'First Epilespy',
                        style: TextStyle(
                            color: Color(0xFF0D47A1),
                            fontSize: 16,
                            fontWeight: FontWeight.bold),
                      ),
                      subtitle:  Text(
                        'Wed,2 july 2022 1:00PM',
                        style: TextStyle(
                          color: Color(0xFF0D47A1),
                          fontSize: 14,
                        ),
                      ),
                      trailing: Text(
                        'Message Sent ',
                        style: TextStyle(
                          color: Colors.blue,
                          fontSize: 16,
                        ),
                      ),
                    )),
              )
            ],
          ),
        ),
      ),
    );
  }
}
