import 'package:flutter/material.dart';

class Video extends StatelessWidget {
  const Video({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: true,
        backgroundColor: const Color(0xFF0D47A1),
        centerTitle: true,
        title: const Text(
          'Video',
          style: TextStyle(
              color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              ListTile(
                leading: Image.asset('assets/images/images1.jpg'),
                title:const Text(
                  '     Title 1',
                  style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
                subtitle: const Text(
                  '     Short Description',
                  style: TextStyle(
                      color: Colors.black,
                      // fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
              ),
              ListTile(
                leading: Image.asset('assets/images/images1.jpg'),
                title:const Text(
                  '     Title 2',
                  style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
                subtitle: const Text(
                  '     Short Description',
                  style: TextStyle(
                      color: Colors.black,
                      // fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
              ),
              ListTile(
                leading: Image.asset('assets/images/images1.jpg'),
                title:const Text(
                  '     Title 3',
                  style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
                subtitle: const Text(
                  '     Short Description',
                  style: TextStyle(
                      color: Colors.black,
                      // fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
              ),
              ListTile(
                leading: Image.asset('assets/images/images1.jpg'),
                title:const Text(
                  '     Title 4',
                  style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
                subtitle: const Text(
                  '     Short Description',
                  style: TextStyle(
                      color: Colors.black,
                      // fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
              ),
              ListTile(
                leading: Image.asset('assets/images/images1.jpg'),
                title:const Text(
                  '     Title 5',
                  style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
                subtitle: const Text(
                  '     Short Description',
                  style: TextStyle(
                      color: Colors.black,
                      // fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
              ),
              ListTile(
                leading: Image.asset('assets/images/images1.jpg'),
                title:const Text(
                  '     Title 6',
                  style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
                subtitle: const Text(
                  '     Short Description',
                  style: TextStyle(
                      color: Colors.black,
                      // fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
              ),
              ListTile(
                leading: Image.asset('assets/images/images1.jpg'),
                title:const Text(
                  '     Title 7',
                  style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
                subtitle: const Text(
                  '     Short Description',
                  style: TextStyle(
                      color: Colors.black,
                      // fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
