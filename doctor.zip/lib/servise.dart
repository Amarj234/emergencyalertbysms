class Serves{
 //String url ="http://192.168.0.105/mypaani/api/";
// String url ="http://192.168.43.130/doctor/";

  String url ="https://ccreative.in/dranchal/";
}